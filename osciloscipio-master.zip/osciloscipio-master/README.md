# osciloscipio
Ejemplo de arduino nano con pantalla oled
descargar las librerias de: 
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
